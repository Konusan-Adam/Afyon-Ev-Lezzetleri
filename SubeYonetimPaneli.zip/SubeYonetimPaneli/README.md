# Afyon Ev Lezzetleri — Şube Yönetim Paneli

Müşteri vitrininden tamamen ayrılmış bağımsız Şube Yönetim Paneli uygulamasıdır.
Ortak Firebase Firestore veritabanını kullanır; siparişler, tezgah stokları, canlı yayın durumu ve tedarikçi hakedişleri müşteri vitrini ile anlık senkronize çalışır.

## Kurulum ve Çalıştırma

```bash
npm install
npm run dev
```

## Üretim Derlemesi

```bash
npm run build
```
